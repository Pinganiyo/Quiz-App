let examData = null;
let timerInterval = null;
let timeRemaining = 0;

const screens = {
    loading: document.getElementById('loading'),
    start: document.getElementById('start-screen'),
    study: document.getElementById('study-screen'),
    exam: document.getElementById('exam-screen'),
    result: document.getElementById('result-screen')
};

function showScreen(screenName) {
    Object.values(screens).forEach(screen => screen.classList.remove('active'));
    screens[screenName].classList.add('active');
}

// Algoritmo Fisher-Yates para barajar (random order)
function shuffle(array) {
    let currentIndex = array.length, randomIndex;
    let newArray = [...array];
    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex--;
        [newArray[currentIndex], newArray[randomIndex]] = [
            newArray[randomIndex], newArray[currentIndex]];
    }
    return newArray;
}

async function loadExam() {
    try {
        const response = await fetch('./json/examen.json');
        if (!response.ok) {
            throw new Error('No se pudo cargar el archivo JSON.');
        }
        const data = await response.json();
        examData = data.examen;
        initStartScreen();
    } catch (error) {
        console.error("Error loading JSON:", error);
        document.querySelector('.loader').style.display = 'none';
        document.getElementById('loading-text').innerHTML = `
            <span style="color: var(--error-color);">Error cargando el examen.</span><br>
            Asegúrate de ejecutar esta página a través de un servidor web (ej. Live Server).<br>
            Los navegadores bloquean peticiones 'fetch' a archivos locales por seguridad (CORS).
        `;
    }
}

function initStartScreen() {
    document.getElementById('quiz-title').textContent = examData.titulo || 'Examen';
    document.getElementById('quiz-desc').textContent = examData.descripcion || 'Por favor, completa el cuestionario.';
    
    document.getElementById('time-limit').innerHTML = `🕒 ${examData.configuracion.tiempo_limite_minutos} min.`;
    document.getElementById('pass-score').innerHTML = `🎯 Aprobar con ${examData.configuracion.puntuacion_minima_aprobado}%`;
    
    document.getElementById('start-btn').addEventListener('click', startExam);
    document.getElementById('study-btn').addEventListener('click', showStudyScreen);
    document.getElementById('back-to-start-btn').addEventListener('click', () => showScreen('start'));
    showScreen('start');
}

function showStudyScreen() {
    const container = document.getElementById('study-container');
    container.innerHTML = '';
    
    examData.preguntas.forEach((q, index) => {
        let correctText = '';
        if (q.tipo === 'seleccion_multiple') {
            const correctOpts = q.opciones.filter(opt => q.respuesta_correcta.includes(opt.id)).map(opt => opt.texto);
            correctText = correctOpts.join(', ');
        } else {
            const correctOpt = q.opciones.find(opt => opt.id === q.respuesta_correcta);
            correctText = correctOpt ? correctOpt.texto : '';
        }
        
        container.innerHTML += `
            <div class="feedback-item correct">
                <p class="feedback-question">${index + 1}. ${q.enunciado}</p>
                <p class="feedback-explanation">
                    <strong style="color: var(--success-color);">Respuesta Correcta:</strong> ${correctText}
                    <br><br>
                    <em style="opacity: 0.8;">${q.explicacion}</em>
                </p>
            </div>
        `;
    });
    
    showScreen('study');
}

function startExam() {
    document.getElementById('exam-title-header').textContent = examData.titulo || 'Examen';
    renderQuestions();
    showScreen('exam');
    
    timeRemaining = examData.configuracion.tiempo_limite_minutos * 60;
    updateTimerDisplay();
    timerInterval = setInterval(() => {
        timeRemaining--;
        updateTimerDisplay();
        if (timeRemaining <= 0) {
            clearInterval(timerInterval);
            submitExam();
        }
    }, 1000);
}

function updateTimerDisplay() {
    const minutes = Math.floor(timeRemaining / 60);
    const seconds = timeRemaining % 60;
    const display = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    const timerElement = document.getElementById('timer');
    timerElement.textContent = display;
    
    // Cambiar color cuando queda menos de 1 minuto
    if (timeRemaining < 60) {
        timerElement.style.color = 'var(--error-color)';
        timerElement.style.background = 'rgba(239, 68, 68, 0.1)';
        timerElement.style.borderColor = 'rgba(239, 68, 68, 0.3)';
    } else {
        timerElement.style.color = 'var(--accent-color)';
        timerElement.style.background = 'rgba(99, 102, 241, 0.1)';
        timerElement.style.borderColor = 'rgba(99, 102, 241, 0.2)';
    }
}

function renderQuestions() {
    const container = document.getElementById('questions-container');
    container.innerHTML = '';
    
    let questions = examData.preguntas;
    if (examData.configuracion.orden_aleatorio) {
        questions = shuffle(questions);
    }
    
    questions.forEach((q, index) => {
        const qCard = document.createElement('div');
        qCard.className = 'question-card';
        
        const qText = document.createElement('h3');
        qText.className = 'question-text';
        qText.textContent = `${index + 1}. ${q.enunciado}`;
        qCard.appendChild(qText);
        
        const optionsGrid = document.createElement('div');
        optionsGrid.className = 'options-grid';
        
        // Barajar opciones si es necesario
        let opciones = q.opciones;
        if (examData.configuracion.orden_aleatorio) {
            opciones = shuffle(opciones);
        }
        
        const inputType = q.tipo === 'seleccion_multiple' ? 'checkbox' : 'radio';
        
        opciones.forEach(opt => {
            const label = document.createElement('label');
            label.className = 'option-label';
            
            const input = document.createElement('input');
            input.type = inputType;
            input.name = `question-${q.id}`;
            input.value = opt.id;
            input.className = 'option-input';
            
            label.appendChild(input);
            label.appendChild(document.createTextNode(opt.texto));
            
            optionsGrid.appendChild(label);
        });
        
        qCard.appendChild(optionsGrid);
        container.appendChild(qCard);
    });
}

document.getElementById('exam-form').addEventListener('submit', (e) => {
    e.preventDefault();
    submitExam();
});

function submitExam() {
    clearInterval(timerInterval);
    
    let score = 0;
    let maxScore = examData.preguntas.length;
    let feedbackHTML = '';
    
    const formData = new FormData(document.getElementById('exam-form'));
    
    examData.preguntas.forEach(q => {
        const userAnswers = formData.getAll(`question-${q.id}`);
        let isCorrect = false;
        
        if (q.tipo === 'seleccion_multiple') {
            const correctAnswers = q.respuesta_correcta;
            if (userAnswers.length === correctAnswers.length && 
                userAnswers.every(val => correctAnswers.includes(val))) {
                isCorrect = true;
            }
        } else {
            if (userAnswers.length > 0 && userAnswers[0] === q.respuesta_correcta) {
                isCorrect = true;
            }
        }
        
        if (isCorrect) score++;
        
        if (examData.configuracion.mostrar_retroalimentacion) {
            feedbackHTML += `
                <div class="feedback-item ${isCorrect ? 'correct' : ''}">
                    <p class="feedback-question">${q.enunciado}</p>
                    <p class="feedback-explanation">
                        <strong>${isCorrect ? '✅ Correcto' : '❌ Incorrecto'}</strong>. 
                        ${q.explicacion}
                    </p>
                </div>
            `;
        }
    });
    
    const percentage = Math.round((score / maxScore) * 100);
    const passed = percentage >= examData.configuracion.puntuacion_minima_aprobado;
    
    // Animar la puntuación
    const scoreTextElement = document.getElementById('score-text');
    let currentPercentage = 0;
    const animationInterval = setInterval(() => {
        if (currentPercentage >= percentage) {
            clearInterval(animationInterval);
            scoreTextElement.textContent = `${percentage}%`;
        } else {
            currentPercentage++;
            scoreTextElement.textContent = `${currentPercentage}%`;
        }
    }, 20);

    const scoreCircle = document.querySelector('.score-circle');
    const color = passed ? 'var(--success-color)' : 'var(--error-color)';
    scoreCircle.style.background = `conic-gradient(${color} ${percentage}%, transparent 0%)`;
    
    const msgElement = document.getElementById('result-msg');
    if (passed) {
        msgElement.textContent = '¡Aprobado!';
        msgElement.className = 'result-msg';
    } else {
        msgElement.textContent = 'No Aprobado';
        msgElement.className = 'result-msg failed';
    }
    
    document.getElementById('feedback-container').innerHTML = feedbackHTML;
    showScreen('result');
}

document.getElementById('retry-btn').addEventListener('click', () => {
    document.getElementById('exam-form').reset();
    showScreen('start');
});

// Iniciar aplicación
document.addEventListener('DOMContentLoaded', loadExam);
